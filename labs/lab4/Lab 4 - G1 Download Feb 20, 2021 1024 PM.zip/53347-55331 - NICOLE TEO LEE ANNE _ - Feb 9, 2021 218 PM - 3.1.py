import string
alphabets = string.ascii_lowercase
first_letter = string.ascii_uppercase
def encode_caesar(plaintext, key):
    ciphertext = ''
    for x in plaintext:
        if x in alphabets:
            i = alphabets.find(x)
            if key+i >= len(alphabets):
                i == key+i - len(alphabets) -1
                ciphertext += alphabets[i]
            else:
                ciphertext += alphabets[i + key]
        elif x in first_letter:
            i = first_letter.find(x)
            if key+i >= len(first_letter):
                i == key+i - len(first_letter) -1
                ciphertext += first_letter[i]
            else:
                ciphertext += first_letter[i + key]
        else:
            ciphertext += x
    return ciphertext