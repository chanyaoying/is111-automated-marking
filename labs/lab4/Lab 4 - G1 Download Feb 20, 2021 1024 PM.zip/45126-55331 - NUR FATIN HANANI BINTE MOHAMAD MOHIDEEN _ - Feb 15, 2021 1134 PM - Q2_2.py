def calculate_rows_of_lights(budget,cost_per_light):
    
    x = budget
    y = cost_per_light
    z = int(x/y)
    
    if z == 1:
        print("1")
        
    elif 2 <= z <= 3:
        print("2")
        
    elif 4 <= z <= 6:
        print("3")
        
    elif 7 <= z <= 10:
        print("4")
        
    elif 11 <= z <= 15:
        print("5")

    elif 16 <= z <= 21:
        print("6")

    elif 22 <= z <= 28:
        print("7")

    elif 29 <= z <= 36:
        print("8")

    elif 37 <= z <= 45:
        print("9")

    elif 46 <= z <= 55:
        print("10")

    else:
        print("0")
    
    return True

print(calculate_rows_of_lights(50,2) == 7)
    