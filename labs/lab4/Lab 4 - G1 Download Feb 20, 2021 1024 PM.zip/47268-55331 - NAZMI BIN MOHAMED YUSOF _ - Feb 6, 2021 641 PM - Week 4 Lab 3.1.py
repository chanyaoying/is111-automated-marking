# Write a Python function encode_caesar that takes in two parameters plaintext and key,
# encrypts the plaintext and then returns the ciphertext (which has been encoded using
# the key). The plaintext is the message to be encrypted to ciphertext, and key is the shift
# (which can be right or left). A key value of 3 indicates that each character in the plaintext
# should be shifted right by 3, and key value of -3 indicates that each character in the
# plaintext should be shifted left by 3.

import string

def encode_caesar(plaintext, key):

    list_plaintext = list(plaintext)
    for i in range(len(list_plaintext)):
        if list_plaintext[i] in string.ascii_lowercase:
            loc_char = string.ascii_lowercase.find(list_plaintext[i])
            new_loc = (loc_char + key) % 26
            new_char = string.ascii_lowercase[new_loc]
            list_plaintext[i] = new_char
        elif list_plaintext[i] in string.ascii_uppercase:
            loc_char = string.ascii_uppercase.find(list_plaintext[i])
            new_loc = (loc_char + key) % 26
            new_char = string.ascii_uppercase[new_loc]
            list_plaintext[i] = new_char

    return "".join(list_plaintext)

print(encode_caesar("If you want something badly enough, do not give up!", -3) == "Fc vlr txkq pljbqefkd yxaiv bklrde, al klq dfsb rm!")
print(encode_caesar("Programming is SO FUN!", 12) == "Bdasdmyyuzs ue EA RGZ!")

quit()