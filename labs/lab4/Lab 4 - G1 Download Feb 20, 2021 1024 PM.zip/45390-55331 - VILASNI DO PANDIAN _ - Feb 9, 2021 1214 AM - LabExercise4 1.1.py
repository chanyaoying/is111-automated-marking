def mask_mobile(mobile_number):
    mobile_number = str(mobile_number)
    output = 'xxxx' + mobile_number[4:]
    return output

print(mask_mobile(87654321) == 'xxxx4321')