def mask_email(email_address):
    length_of_local= email_address.index('@')
    masked_email = '*'*length_of_local + email_address[length_of_local:]
    return masked_email