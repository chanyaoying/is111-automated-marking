def mask_mobile(x):

    x = str(x)
    y = x[4:]
    print('xxxx'+ y)

x =input()
mask_mobile(x)