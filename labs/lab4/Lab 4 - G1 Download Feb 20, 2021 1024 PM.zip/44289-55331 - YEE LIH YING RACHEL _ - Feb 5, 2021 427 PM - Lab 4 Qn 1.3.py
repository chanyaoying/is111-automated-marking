def get_num_solutions(a,b,c):
    solutions_count = 0
    if b**2 - 4*a*c > 0:
        solutions_count = 2
        return solutions_count
    elif b**2 - 4*a*c == 0:
        solutions_count = 1
        return solutions_count
    else:
        return solutions_count