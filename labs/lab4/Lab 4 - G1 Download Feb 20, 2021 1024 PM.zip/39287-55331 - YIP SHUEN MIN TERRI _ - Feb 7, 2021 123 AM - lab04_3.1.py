def encode_caesar(plaintext, key):
    import string
    plaintext=plaintext.lower() # not sure how to change back to uppercase
    alphabet = string.ascii_lowercase
    shifted_alphabet = alphabet[key:] + alphabet[:key]
    table = str.maketrans(alphabet, shifted_alphabet)
    return plaintext.translate(table)

test=encode_caesar("If you want something badly enough, do not give up!", -3)
print(test)

print(encode_caesar("If you want something badly enough, do not give up!", -3) == "Fc vlr txkq pljbqefkd yxaiv bklrde, al klq dfsb rm!")
print(encode_caesar("Programming is SO FUN!", 12) ==
"Bdasdmyyuzs ue EA RGZ!")