def pass_ippt(pushup_score, situp_Score, run_score):
    if pushup_score > 25 or situp_Score > 25 or run_score > 50 or pushup_score < 0 or situp_Score < 0 or run_score < 0:
        print("Please put valid score")
    elif pushup_score == 0 or situp_Score == 0 or run_score == 0 or pushup_score + situp_Score + run_score < 51:
        return False
    else:
        return True

print(pass_ippt(10,20,20) == False)
print(pass_ippt(20,0,40) == False)
print(pass_ippt(20,15,33) == True)
