# Write a Python function pass_ippt that takes in 3 integer parameters pushup_score,
# situp_score and run_score. The function pass_ippt should return True if the NSman
# has passed his IPPT (based on the two criteria mentioned above), and False if the NSman
# has failed his IPPT.

def pass_ippt(pushup_score, situp_score, run_score):
    total = pushup_score + situp_score + run_score
    if pushup_score == 0 or situp_score == 0 or run_score == 0 or total < 51:
        return False
    else:
        return True

print(pass_ippt(10,20,20) == False)
print(pass_ippt(20,0,40) == False)
print(pass_ippt(20,15,33) == True)

quit()