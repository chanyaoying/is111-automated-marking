#2.1 
def pass_ippt (x,y,z):
    if x >= 1 and y >= 1 and z >= 1:
        return True
    else:
        return False
    if sum(x,y,z) >= 51:
        return True
    else:
        return False

print(pass_ippt(20,15,33))