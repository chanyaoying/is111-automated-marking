#1.4

def pass_ippt (a,b,c):
    if  a >= 1 and b >= 1 and c >= 1:  # criteria
        if  a + b + c >= 51:
            return True   
    
    return False
    

print(pass_ippt(10,20,20) == False)
