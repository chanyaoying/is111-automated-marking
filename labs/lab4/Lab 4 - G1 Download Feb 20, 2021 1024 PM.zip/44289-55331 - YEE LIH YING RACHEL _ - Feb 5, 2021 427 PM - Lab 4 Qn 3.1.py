def encode_caesar(plaintext, key):
    import string
    encoded_text = ''
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    for i in plaintext:
        if i in lower:
            encoded_text += lower[(lower.index(i) + key)%len(lower)]
        elif i in upper:
            encoded_text += upper[(upper.index(i) + key)%len(upper)]
        else:
            encoded_text += i
    return encoded_text