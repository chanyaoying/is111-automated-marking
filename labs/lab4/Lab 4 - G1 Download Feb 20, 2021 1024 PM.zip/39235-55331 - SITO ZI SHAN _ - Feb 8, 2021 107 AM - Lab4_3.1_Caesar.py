#Lab Exercise 4, Sito Zi Shan (G1)
#Q 3.1

def encode_caesar(plaintext, key):
    encrypted = ""
    for i in range(len(plaintext)):
         char = plaintext[i]
         if (char.isupper()):
             encrypted += chr((ord(char) + key-65) % 26 + 65)
         elif (char.isspace()):
             encrypted += " "
         elif (char.islower()):
             encrypted += chr((ord(char) + key - 97) % 26 + 97)
         else:
             encrypted += plaintext[i]
    return encrypted
