def calculate_rows_of_lights(budget, cost_per_light):
    number_of_lights = budget//cost_per_light
    rows = 0
    for i in range(number_of_lights):
        light_used = 0.5*i**2 + 1.5*i + 1
        if light_used <= number_of_lights:
            rows += 1
        else:
            break
    return rows

print(calculate_rows_of_lights(50,2) == 6)
print(calculate_rows_of_lights(100,3) == 7)
print(calculate_rows_of_lights(10,12) == 0)