#1.2
import string

def mask_email(email):
    
    local = email[:email.find('@')]
    domain = email[email.find('@'):]

    for i in local:
        local = local.replace(i,'*')
        
    if len(local) <= 64 and len(domain) <= 255:
        return (local + domain)
    else:
        print ('invalid email')
        
print(mask_email('abcdef@yahoo.com'))
print(mask_email('is111@gmail.com'))