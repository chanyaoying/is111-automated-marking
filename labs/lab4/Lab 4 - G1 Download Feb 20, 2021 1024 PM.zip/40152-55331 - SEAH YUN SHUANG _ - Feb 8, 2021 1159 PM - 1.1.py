def mask_mobile (num):
    mask="****" + str(num) [4:]
    return mask

mask_mobile("87654321")