def encode_caesar(plaintext, key):
    import string
    s = ''
    for i in range(len(plaintext)):
        if plaintext[i] in string.ascii_uppercase:
            k = string.ascii_uppercase.index(plaintext[i])
            if k+key > 25:
                s += string.ascii_uppercase[k+key-26]
            else:
                s += string.ascii_uppercase[k+key]
        elif plaintext[i] in string.ascii_lowercase:
            j = string.ascii_lowercase.index(plaintext[i])
            if j+key > 25:
                s += string.ascii_lowercase[j+key-26]
            else:
                s += string.ascii_lowercase[j+key]
        else:
            s += plaintext[i]
    return s

print(encode_caesar("If you want something badly enough, do not give up!", -3) == "Fc vlr txkq pljbqefkd yxaiv bklrde, al klq dfsb rm!")
print(encode_caesar("Programming is SO FUN!", 12) == "Bdasdmyyuzs ue EA RGZ!")