import math
def get_num_solutions(a,b,c):
    sum_eqn = ((b**2) - 4*a*c)

    if sum_eqn > 0:
        print("2")
    
    elif sum_eqn == 0:
        print("1")

    else:
        print("0")

    return True

print(get_num_solutions(3,6,3) == 1)