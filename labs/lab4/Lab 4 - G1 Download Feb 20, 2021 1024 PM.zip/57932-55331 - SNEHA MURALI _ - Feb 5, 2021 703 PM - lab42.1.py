def pass_ippt(pushup_score,situp_score,run_score):
    totalscore = int(pushup_score) + int(situp_score) + int(run_score)
    if pushup_score >0 and situp_score >0 and run_score>0 and totalscore >= 51:
        return True
    else:
        return False