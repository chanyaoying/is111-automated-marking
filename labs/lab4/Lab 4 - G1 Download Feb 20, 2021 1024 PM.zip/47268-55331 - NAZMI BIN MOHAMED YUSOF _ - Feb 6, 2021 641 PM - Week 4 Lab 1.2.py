# An email address is typically of the format local-part@domain, where the local part may be
# up to 64 characters long and the domain may have a maximum of 255 characters. Email
# masking hides all or part of the local part of the email address. An example of a masked
# email address abcdef@gmail.com is given by ******@gmail.com.
# Write a Python function mask_email that takes in a string parameter email_address
# containing a valid email address, and then returns the masked email address.

# print(mask_email('abcdef@gmail.com') == '******@gmail.com')
# print(mask_email('is111@gmail.com') == '*****@gmail.com')

def mask_email(x):
    loc_of_at = x.find('@')
    len_localpart = len(x[:loc_of_at])
    len_domain = len(x[loc_of_at+1:])
    if len_localpart <= 64 and len_domain <= 255:
        return '*' * len_localpart + x[loc_of_at:]
    else:
        return 'Invalid'

print(mask_email('abcdef@gmail.com') == '******@gmail.com')
print(mask_email('is111@gmail.com') == '*****@gmail.com')

quit()