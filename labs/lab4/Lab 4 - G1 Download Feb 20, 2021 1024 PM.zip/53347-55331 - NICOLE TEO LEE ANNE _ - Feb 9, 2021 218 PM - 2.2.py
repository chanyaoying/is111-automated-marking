def calculate_rows_of_lights(budget, cost_per_light):
    no_of_lights = budget // cost_per_light
    y = 0
    for i in range(no_of_lights+1):
        y += i
        if y >= no_of_lights:
            break
    if y == no_of_lights:
        return i
    if y > no_of_lights:
        return i-1