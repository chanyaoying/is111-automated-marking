def calculate_rows_of_lights(budget, cost_per_light):
    number_of_lights_afforded = budget//cost_per_light
    sum_of_bulbs_rows = 0
    total_rows = 0
    for i in range(1,number_of_lights_afforded):
        if sum_of_bulbs_rows + i < number_of_lights_afforded:
            sum_of_bulbs_rows += i
        else:
            total_rows = i - 1
            break
    return total_rows