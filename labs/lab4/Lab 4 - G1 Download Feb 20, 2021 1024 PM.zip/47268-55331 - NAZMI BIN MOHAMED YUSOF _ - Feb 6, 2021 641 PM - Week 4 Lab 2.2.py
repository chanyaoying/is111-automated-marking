# You are given the task of decorating the Christmas tree with lights, using a budget $x. Each
# light costs $y. The lights have to be decorated on the tree, in the following way:
# Write a Python function calculate_rows_of_lights that takes in two parameters:
# ● budget, which is the total amount of money that you are allowed to spend; and
# ● cost_per_light, which is the cost of each light.
# Your function should return the maximum number of rows of lights that can be decorated
# using the budget that you are given, and taking into consideration the cost_per_light.
# You can use the following code snippet to test your code:

def calculate_rows_of_lights(budget, cost_per_light):
    
    no_of_lights = budget // cost_per_light
    max_row = 0
    for i in range(no_of_lights):
        no_of_lights -= i+1
        if no_of_lights > 0:
                max_row += 1
        else:
            break
    
    return max_row

print(calculate_rows_of_lights(50,2) == 6)
print(calculate_rows_of_lights(100,3) == 7)
print(calculate_rows_of_lights(10,12) == 0)

quit()