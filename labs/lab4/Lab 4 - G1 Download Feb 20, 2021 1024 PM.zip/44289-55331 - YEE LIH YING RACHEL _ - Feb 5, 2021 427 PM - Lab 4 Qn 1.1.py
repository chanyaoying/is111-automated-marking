def mask_mobile(mobile_number):
    mobile_number = str(mobile_number)
    masked_number = '****'
    for i in range(4,len(mobile_number)):
        masked_number += mobile_number[i]
    return masked_number