# Write a Python function get_num_solutions that takes in 3 integer parameters a, b and c,
# and returns the number of solutions for the quadratic equation ax2 + bx + c = 0

def get_num_solutions(a, b, c):
    
    rule = b**2 - 4*a*c
    if rule > 0:
        no_sln = 2
    elif rule == 0:
        no_sln = 1
    else:
        no_sln = 0
    
    return no_sln

print(get_num_solutions(4,5,6) == 0)
print(get_num_solutions(3,6,3) == 1)
print(get_num_solutions(2,4,1) == 2)

quit()