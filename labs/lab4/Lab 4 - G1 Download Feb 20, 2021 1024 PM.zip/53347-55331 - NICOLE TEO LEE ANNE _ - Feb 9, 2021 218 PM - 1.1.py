def mask_mobile(x):
    x = str(x)
    y = '****'
    for i in range(4,len(x)):
        y += x[i]
    return y