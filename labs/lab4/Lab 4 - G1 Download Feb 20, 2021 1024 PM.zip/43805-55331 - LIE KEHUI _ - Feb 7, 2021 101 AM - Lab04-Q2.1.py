#2.1
def pass_ippt(pushup_score, situp_score, run_score):
    total_score = 0
    if pushup_score > 0 and pushup_score <= 25:
        total_score += pushup_score
    else:
        return False
    
    if situp_score > 0 and situp_score <= 25:
        total_score += pushup_score
    else:
        return False
    
    if run_score > 0 and run_score <= 50:
        total_score += run_score
    else:
        return False
    
    if total_score < 50:
        return False
    else:
        return True
    
print(pass_ippt(10,20,20) == False)
print(pass_ippt(20,0,40) == False)
print(pass_ippt(20,15,33) == True)