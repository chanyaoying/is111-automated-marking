def mask_email(email_address):
    y = ''
    for i in range(len(email_address)):
        if email_address[i] != '@':
            y += '*'
        if email_address[i] == '@':
            y += '@' + email_address[i+1:]
            break
    return y