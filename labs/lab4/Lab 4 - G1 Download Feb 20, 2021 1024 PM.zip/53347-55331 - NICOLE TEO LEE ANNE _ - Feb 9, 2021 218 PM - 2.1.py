def pass_ippt(pushup_score, situp_score, run_score):
    Sum = pushup_score + situp_score + run_score
    if pushup_score == 0 or situp_score == 0 or run_score == 0 or Sum < 51:
        return False
    else:
        return True