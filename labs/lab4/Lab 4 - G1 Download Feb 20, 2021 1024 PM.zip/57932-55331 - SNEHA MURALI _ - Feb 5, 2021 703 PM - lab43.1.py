import string
def encode_caesar(a,b):
    b = int(b)
    returnstring = ''
    for i in a:
        if i not in string.ascii_letters:
            returnstring = returnstring + i 
        elif i in string.ascii_lowercase:
            position = string.ascii_lowercase.find(i)
            if position+b > 25:
                newposition = string.ascii_lowercase[b - (25-position)-1]
                returnstring = returnstring + newposition
            else:
                newposition = string.ascii_lowercase[position+b]
                returnstring = returnstring + newposition
        elif i in string.ascii_uppercase:
            position = string.ascii_uppercase.find(i)
            if position+b > 25:
                newposition = string.ascii_uppercase[b - (25-position)-1]
                returnstring = returnstring + newposition
            else: 
                newposition = string.ascii_uppercase[position+b]
                returnstring = returnstring + newposition
    return returnstring