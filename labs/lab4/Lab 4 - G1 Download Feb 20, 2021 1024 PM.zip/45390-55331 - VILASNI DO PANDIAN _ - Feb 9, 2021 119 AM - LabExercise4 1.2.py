def mask_email(email_address):
    email_address = str(email_address)
    a = email_address[:-10]
    for i in a:
        a = a.replace(i,'*')
    for ch in a: 
        a = a.replace(ch,'*')
    return a + email_address[len(a):]

print(mask_email('abcdef@gmail.com') == '******@gmail.com')
print(mask_email('is111@gmail.com') == '*****@gmail.com')