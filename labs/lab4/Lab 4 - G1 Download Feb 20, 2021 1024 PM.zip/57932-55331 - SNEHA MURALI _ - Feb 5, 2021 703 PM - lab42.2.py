def calculate_rows_of_lights(budget, cost_per_light):
    num_lights = int(budget)//int(cost_per_light)
    if num_lights == 0:
        return 0 
    sumof = 0
    for i in range(1,num_lights):
        sumof = sumof + i
        if sumof > num_lights:
            break 
    
    return i-1
   