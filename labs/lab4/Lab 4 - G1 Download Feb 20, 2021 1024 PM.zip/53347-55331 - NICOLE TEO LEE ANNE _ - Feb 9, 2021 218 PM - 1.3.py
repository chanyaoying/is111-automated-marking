def get_num_solutions(a, b, c):
    quadratic_eqn = b**2 - 4*a*c
    solution = 0
    if quadratic_eqn > 0:
        solution = 2
    if quadratic_eqn == 0:
        solution = 1
    if quadratic_eqn < 0:
        solution = 0
    return solution