def pass_ippt(pushup_score,situp_score,run_score):
    total = pushup_score + situp_score + run_score
    if total >= 51 and pushup_score >=1 and situp_score >=1 and run_score >= 1:
        return True
    else:
        return False