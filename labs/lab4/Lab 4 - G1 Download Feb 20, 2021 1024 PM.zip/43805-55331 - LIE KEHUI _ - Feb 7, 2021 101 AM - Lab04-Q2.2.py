#2.2
def calculate_rows_of_lights(budget,cost_per_light):
    budget = float(budget)
    cost_per_light = float(cost_per_light)
    total_lights = int(budget//cost_per_light)
    rows = 0
    for i in range(1,total_lights + 1):
        total_lights -= i
        if total_lights > 0:
            rows += 1
        elif total_lights <= 0:
            break
    return rows

print(calculate_rows_of_lights(50,2) == 6)
print(calculate_rows_of_lights(100,3) == 7)
print(calculate_rows_of_lights(10,12) == 0)