#Lab Exercise 4, Sito Zi Shan (G1)
#Q 2.2

def calculate_rows_of_lights(budget,cost_per_light):
    number_of_lights = budget//cost_per_light
    row = 0
    for i in range(number_of_lights):
        if number_of_lights >= 0 and number_of_lights >= i:
            number_of_lights -= i
            if number_of_lights >= i:
                row +=1
    return row
         
print(calculate_rows_of_lights(50,2) == 6)
print(calculate_rows_of_lights(100,3) == 7)
print(calculate_rows_of_lights(10,12) == 0)
