def mask_email(input_email):
    pos = input_email.find("@")
    start = input_email[:pos]
    end = input_email[pos:]
    
    return (len(start)*"*"+end)



print(mask_email('abcdef@gmail.com') == '******@gmail.com')