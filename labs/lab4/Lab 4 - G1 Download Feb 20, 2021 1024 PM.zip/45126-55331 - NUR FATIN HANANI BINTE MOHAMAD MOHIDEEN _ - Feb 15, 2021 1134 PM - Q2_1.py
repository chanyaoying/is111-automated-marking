def pass_ippt(pushup_score, situp_score, run_score):
    
    total_score = pushup_score + situp_score + run_score 

    if total_score > 50 and pushup_score >= 1 and situp_score >= 1 and run_score >= 1:
        print("True")

    else:
        print("False")

    return pass_ippt

print(pass_ippt(20,0,20))

