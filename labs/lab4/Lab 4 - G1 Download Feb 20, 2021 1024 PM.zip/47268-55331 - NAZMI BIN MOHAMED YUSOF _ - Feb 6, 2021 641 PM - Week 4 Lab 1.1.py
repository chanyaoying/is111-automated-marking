# Write a Python function mask_mobile that takes in an integer parameter mobile_number
# containing an 8-digit mobile number, and then returns the masked mobile number.
# the following statements should print True
# print(mask_mobile(87654321) == '****4321')
# print(mask_mobile(91234567) == '****4567')

def mask_mobile(x):
    y = str(x)
    return '****' + y[4:]

print(mask_mobile(87654321) == '****4321')
print(mask_mobile(91234567) == '****4567')

quit()