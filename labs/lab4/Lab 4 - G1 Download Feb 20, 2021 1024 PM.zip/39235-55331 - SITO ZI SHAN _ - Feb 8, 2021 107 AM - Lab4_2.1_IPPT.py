#Lab Exercise 4, Sito Zi Shan (G1)
#Q 2.1

def pass_ippt(pushup_score, situp_score, run_score):
    passes = 0
    total_score = pushup_score + situp_score + run_score
    if pushup_score <=0 or situp_score <=0 or run_score<=0:
        return False
    if pushup_score >= 1:
        passes +=1
    if situp_score >=1:
        passes +=1
    if run_score >=1:
        passes +=1
    if passes >=2 and total_score>= 51:
        return True
    else:
        return False
