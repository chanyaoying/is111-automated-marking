#Lab Exercise 4, Sito Zi Shan (G1)
#Q 1.2
def mask_email(email_address):
    if email_address == email_address.lower():
        to_mask = email_address.split("@")[0]
        for digits in to_mask:
            masked = len(to_mask) * "*"
    return masked + "@"+ email_address.split("@")[1]
