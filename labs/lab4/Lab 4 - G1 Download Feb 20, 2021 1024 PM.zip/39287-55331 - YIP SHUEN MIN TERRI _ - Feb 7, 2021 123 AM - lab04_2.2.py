def calculate_rows_of_lights(budget, cost_per_light):
    import math
    number=math.floor(budget/cost_per_light)
    x=[]
    for i in range(1,100):
        x.append(float(sum(range(1,i))))
    print(x)
    return x.index(number)  # not in list, need to find nearest integer rounded down, not sure how

print(calculate_rows_of_lights(50,2) == 6)
print(calculate_rows_of_lights(100,3) == 7)
print(calculate_rows_of_lights(10,12) == 0)