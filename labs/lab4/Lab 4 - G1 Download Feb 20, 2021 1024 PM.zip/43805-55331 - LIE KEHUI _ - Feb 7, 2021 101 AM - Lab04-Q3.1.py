import string

def encode_caesar(plaintext,key):
    lowerstr = list(string.ascii_lowercase)
    upperstr = list(string.ascii_uppercase)
    key %= 26
    ciphertext = ''

    for i in plaintext:
        if i in lowerstr:
            position = lowerstr.index(i) + key - len(lowerstr)
            ciphertext += lowerstr[position]
        elif i in upperstr:
            position = upperstr.index(i) + key - len(upperstr)
            ciphertext += upperstr[position]
        else:
            ciphertext += i
    return ciphertext

print(encode_caesar("If you want something badly enough, do not give up!", -3) == "Fc vlr txkq pljbqefkd yxaiv bklrde, al klq dfsb rm!")
print(encode_caesar("Programming is SO FUN!", 12) == "Bdasdmyyuzs ue EA RGZ!")
