#Lab Exercise 4, Sito Zi Shan (G1)
#Q 1.1

def mask_mobile(number):
    if len(str(number)) == 8:
        return '****' + str(number)[4:8]
    return
